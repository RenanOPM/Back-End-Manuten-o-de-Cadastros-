const sequelize = require('../config/database');
const Categoria = require('./Categoria');
const Produto = require('./Produto');
const Cliente = require('./Cliente');
const Entregador = require('./Entregador');
const Veiculo = require('./Veiculo');
const EnderecoEntrega = require('./EnderecoEntrega');
const Pedido = require('./Pedido');
const ItemPedido = require('./ItemPedido');
const Pagamento = require('./Pagamento');
const Avaliacao = require('./Avaliacao');

// Cadastros básicos
Categoria.hasMany(Produto, { foreignKey: 'categoriaId', as: 'produtos' });
Produto.belongsTo(Categoria, { foreignKey: 'categoriaId', as: 'categoria' });

Entregador.hasOne(Veiculo, { foreignKey: 'entregadorId', as: 'veiculo' });
Veiculo.belongsTo(Entregador, { foreignKey: 'entregadorId', as: 'entregador' });

// Endereço de entrega
Cliente.hasMany(EnderecoEntrega, { foreignKey: 'clienteId', as: 'enderecos' });
EnderecoEntrega.belongsTo(Cliente, { foreignKey: 'clienteId', as: 'cliente' });

// Pedido
Cliente.hasMany(Pedido, { foreignKey: 'clienteId', as: 'pedidos' });
Pedido.belongsTo(Cliente, { foreignKey: 'clienteId', as: 'cliente' });

EnderecoEntrega.hasMany(Pedido, { foreignKey: 'enderecoEntregaId', as: 'pedidos' });
Pedido.belongsTo(EnderecoEntrega, { foreignKey: 'enderecoEntregaId', as: 'enderecoEntrega' });

Entregador.hasMany(Pedido, { foreignKey: 'entregadorId', as: 'pedidos' });
Pedido.belongsTo(Entregador, { foreignKey: 'entregadorId', as: 'entregador' });

// Itens do Pedido
Pedido.hasMany(ItemPedido, { foreignKey: 'pedidoId', as: 'itens' });
ItemPedido.belongsTo(Pedido, { foreignKey: 'pedidoId', as: 'pedido' });

Produto.hasMany(ItemPedido, { foreignKey: 'produtoId', as: 'itensPedido' });
ItemPedido.belongsTo(Produto, { foreignKey: 'produtoId', as: 'produto' });

// Pagamento
Pedido.hasMany(Pagamento, { foreignKey: 'pedidoId', as: 'pagamentos' });
Pagamento.belongsTo(Pedido, { foreignKey: 'pedidoId', as: 'pedido' });

// Avaliação
Pedido.hasOne(Avaliacao, { foreignKey: 'pedidoId', as: 'avaliacao' });
Avaliacao.belongsTo(Pedido, { foreignKey: 'pedidoId', as: 'pedido' });

Cliente.hasMany(Avaliacao, { foreignKey: 'clienteId', as: 'avaliacoes' });
Avaliacao.belongsTo(Cliente, { foreignKey: 'clienteId', as: 'cliente' });

module.exports = {
  sequelize,
  Categoria,
  Produto,
  Cliente,
  Entregador,
  Veiculo,
  EnderecoEntrega,
  Pedido,
  ItemPedido,
  Pagamento,
  Avaliacao,
};
