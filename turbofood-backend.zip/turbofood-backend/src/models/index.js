const sequelize = require('../config/database');
const Categoria = require('./Categoria');
const Produto = require('./Produto');
const Cliente = require('./Cliente');
const Entregador = require('./Entregador');
const Veiculo = require('./Veiculo');

// Associações
Categoria.hasMany(Produto, { foreignKey: 'categoriaId', as: 'produtos' });
Produto.belongsTo(Categoria, { foreignKey: 'categoriaId', as: 'categoria' });

Entregador.hasOne(Veiculo, { foreignKey: 'entregadorId', as: 'veiculo' });
Veiculo.belongsTo(Entregador, { foreignKey: 'entregadorId', as: 'entregador' });

module.exports = {
  sequelize,
  Categoria,
  Produto,
  Cliente,
  Entregador,
  Veiculo,
};
