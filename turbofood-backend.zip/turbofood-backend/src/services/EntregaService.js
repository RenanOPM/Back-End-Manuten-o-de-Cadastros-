/**
 * EntregaService
 * Caso de uso: Finalizar Entrega / Avaliação / Cancelamento [RF41]
 *
 * Regras de Negócio:
 *  RN01 – Entregador disponível: somente um entregador com status "ativo"
 *          pode ser atribuído à entrega (transação: verifica status do entregador +
 *          atualiza Pedido + muda status do Entregador para "em_entrega").
 *  RN02 – Uma avaliação por pedido: o sistema impede mais de uma avaliação
 *          para o mesmo pedido e só permite avaliar pedidos com status "entregue"
 *          (transação: verifica existência de avaliação + cria Avaliacao +
 *          atualiza média no Pedido se desejado).
 */

const { sequelize, Pedido, Entregador, Avaliacao } = require('../models');

const PROGRESSAO_ENTREGA = {
  pronto: 'saiu_para_entrega',
  saiu_para_entrega: 'entregue',
};

class EntregaService {
  // ────────────────────────────────────────────────────────────────────────────
  // READ
  // ────────────────────────────────────────────────────────────────────────────

  static async findAll() {
    return Pedido.findAll({
      where: { status: ['pronto', 'saiu_para_entrega', 'entregue'] },
      order: [['createdAt', 'DESC']],
      include: [
        { association: 'cliente', attributes: { exclude: ['senha'] } },
        { association: 'enderecoEntrega' },
        { association: 'itens', include: [{ association: 'produto' }] },
        { association: 'entregador', attributes: { exclude: ['senha'] } },
        { association: 'avaliacao' },
      ],
    });
  }

  static async findById(id) {
    const pedido = await Pedido.findByPk(id, {
      include: [
        { association: 'cliente', attributes: { exclude: ['senha'] } },
        { association: 'enderecoEntrega' },
        { association: 'itens', include: [{ association: 'produto' }] },
        { association: 'entregador', attributes: { exclude: ['senha'] } },
        { association: 'avaliacao' },
        { association: 'pagamentos' },
      ],
    });
    if (!pedido) throw new Error('Pedido não encontrado.');
    return pedido;
  }

  // ────────────────────────────────────────────────────────────────────────────
  // ATRIBUIR ENTREGADOR ao pedido (transação atômica) – RN01
  // ────────────────────────────────────────────────────────────────────────────

  static async atribuirEntregador(pedidoId, entregadorId) {
    const pedido = await Pedido.findByPk(pedidoId);
    if (!pedido) throw new Error('Pedido não encontrado.');
    if (pedido.status !== 'pronto') {
      throw new Error(
        `O pedido precisa estar com status "pronto" para receber um entregador. Status atual: "${pedido.status}".`
      );
    }

    // RN01 – Entregador deve estar ativo
    const entregador = await Entregador.findByPk(entregadorId);
    if (!entregador) throw new Error('Entregador não encontrado.');
    if (entregador.status !== 'ativo') {
      throw new Error(
        `O entregador "${entregador.nomeCompleto}" não está disponível. Status atual: "${entregador.status}".`
      );
    }

    const t = await sequelize.transaction();
    try {
      // Associa entregador e avança status do pedido
      await pedido.update(
        { entregadorId, status: 'saiu_para_entrega' },
        { transaction: t }
      );

      // Marca entregador como "em_entrega"
      await entregador.update({ status: 'em_entrega' }, { transaction: t });

      await t.commit();
      return this.findById(pedidoId);
    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  // ────────────────────────────────────────────────────────────────────────────
  // CONFIRMAR ENTREGA (transação atômica)
  // ────────────────────────────────────────────────────────────────────────────

  static async confirmarEntrega(pedidoId) {
    const pedido = await Pedido.findByPk(pedidoId, {
      include: [{ association: 'entregador' }],
    });
    if (!pedido) throw new Error('Pedido não encontrado.');
    if (pedido.status !== 'saiu_para_entrega') {
      throw new Error(
        `Somente pedidos com status "saiu_para_entrega" podem ser confirmados como entregues. Status atual: "${pedido.status}".`
      );
    }

    const t = await sequelize.transaction();
    try {
      await pedido.update({ status: 'entregue' }, { transaction: t });

      // Libera o entregador
      if (pedido.entregador) {
        await pedido.entregador.update({ status: 'ativo' }, { transaction: t });
      }

      await t.commit();
      return this.findById(pedidoId);
    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  // ────────────────────────────────────────────────────────────────────────────
  // AVALIAR PEDIDO (transação atômica) – RN02
  // ────────────────────────────────────────────────────────────────────────────

  static async avaliar(req) {
    const { pedidoId, clienteId, notaComida, notaEntrega, comentario } = req.body;

    if (!pedidoId || !clienteId || !notaComida || !notaEntrega) {
      throw new Error('pedidoId, clienteId, notaComida e notaEntrega são obrigatórios.');
    }

    const pedido = await Pedido.findByPk(pedidoId, {
      include: [{ association: 'avaliacao' }],
    });
    if (!pedido) throw new Error('Pedido não encontrado.');

    // RN02a – Pedido deve estar entregue
    if (pedido.status !== 'entregue') {
      throw new Error('Somente pedidos com status "entregue" podem ser avaliados.');
    }

    // RN02b – Uma avaliação por pedido
    if (pedido.avaliacao) {
      throw new Error('Este pedido já possui uma avaliação registrada.');
    }

    const t = await sequelize.transaction();
    try {
      const avaliacao = await Avaliacao.create(
        { pedidoId, clienteId, notaComida, notaEntrega, comentario },
        { transaction: t }
      );

      await t.commit();

      return await Avaliacao.findByPk(avaliacao.id, {
        include: [
          { association: 'pedido' },
          { association: 'cliente', attributes: { exclude: ['senha'] } },
        ],
      });
    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  // ────────────────────────────────────────────────────────────────────────────
  // Alias genérico para o controller
  // ────────────────────────────────────────────────────────────────────────────

  static async create(req) {
    // Rota genérica: atribui entregador ou avança status
    const { acao, pedidoId, entregadorId } = req.body;
    if (acao === 'atribuir') return this.atribuirEntregador(pedidoId, entregadorId);
    if (acao === 'confirmar') return this.confirmarEntrega(pedidoId);
    if (acao === 'avaliar') return this.avaliar(req);
    throw new Error('Ação inválida. Use: "atribuir", "confirmar" ou "avaliar".');
  }

  static async remove(pedidoId) {
    // Cancelamento de entrega (volta para "pronto" e libera o entregador)
    const pedido = await Pedido.findByPk(pedidoId, {
      include: [{ association: 'entregador' }],
    });
    if (!pedido) throw new Error('Pedido não encontrado.');
    if (pedido.status !== 'saiu_para_entrega') {
      throw new Error(
        'Só é possível cancelar a entrega de pedidos com status "saiu_para_entrega".'
      );
    }

    const t = await sequelize.transaction();
    try {
      await pedido.update({ status: 'pronto', entregadorId: null }, { transaction: t });
      if (pedido.entregador) {
        await pedido.entregador.update({ status: 'ativo' }, { transaction: t });
      }
      await t.commit();
      return { mensagem: 'Entrega cancelada. Pedido retornou ao status "pronto".' };
    } catch (error) {
      await t.rollback();
      throw error;
    }
  }
}

module.exports = EntregaService;
