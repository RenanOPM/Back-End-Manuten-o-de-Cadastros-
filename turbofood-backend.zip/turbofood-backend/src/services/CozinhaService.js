/**
 * CozinhaService
 * Caso de uso: Finalizar Cozinha [RF37]
 *
 * Regras de Negócio:
 *  RN01 – Bloqueio de preparo sem aprovação: o pedido só pode avançar para "em_preparo"
 *          se houver pelo menos um pagamento com status "aprovado"
 *          (transação: valida pagamento + atualiza status do Pedido).
 *  RN02 – Progressão de status obrigatória: os status seguem a ordem
 *          confirmado → em_preparo → pronto. Não é permitido pular etapas
 *          (transação: verifica status atual + atualiza para o próximo).
 */

const { sequelize, Pedido, Pagamento } = require('../models');

// Mapa de progressão da cozinha
const PROGRESSAO = {
  confirmado: 'em_preparo',
  em_preparo: 'pronto',
};

class CozinhaService {
  // ────────────────────────────────────────────────────────────────────────────
  // Helpers
  // ────────────────────────────────────────────────────────────────────────────

  static async _verificarRegrasDeNegocio(pedido) {
    // RN02 – Status deve estar dentro da progressão da cozinha
    if (!PROGRESSAO[pedido.status]) {
      throw new Error(
        `O pedido está com status "${pedido.status}", que não pode ser avançado pela cozinha. ` +
        'São aceitos: "confirmado" e "em_preparo".'
      );
    }

    // RN01 – Deve existir pagamento aprovado (obrigatório para sair de "confirmado")
    if (pedido.status === 'confirmado') {
      const pagamentoAprovado = await Pagamento.findOne({
        where: { pedidoId: pedido.id, status: 'aprovado' },
      });
      if (!pagamentoAprovado) {
        throw new Error(
          'Não é possível iniciar o preparo: o pedido não possui pagamento aprovado.'
        );
      }
    }

    return PROGRESSAO[pedido.status];
  }

  // ────────────────────────────────────────────────────────────────────────────
  // Listar pedidos relevantes para a cozinha
  // ────────────────────────────────────────────────────────────────────────────

  static async findAll() {
    return Pedido.findAll({
      where: { status: ['confirmado', 'em_preparo', 'pronto'] },
      order: [['createdAt', 'ASC']],
      include: [
        { association: 'cliente', attributes: { exclude: ['senha'] } },
        { association: 'enderecoEntrega' },
        { association: 'itens', include: [{ association: 'produto' }] },
        { association: 'pagamentos' },
      ],
    });
  }

  static async findById(id) {
    const pedido = await Pedido.findByPk(id, {
      include: [
        { association: 'cliente', attributes: { exclude: ['senha'] } },
        { association: 'itens', include: [{ association: 'produto' }] },
        { association: 'pagamentos' },
      ],
    });
    if (!pedido) throw new Error('Pedido não encontrado.');
    return pedido;
  }

  // ────────────────────────────────────────────────────────────────────────────
  // AVANÇAR status (transação atômica)
  // ────────────────────────────────────────────────────────────────────────────

  static async avancarStatus(id) {
    const pedido = await Pedido.findByPk(id);
    if (!pedido) throw new Error('Pedido não encontrado.');

    const novoStatus = await this._verificarRegrasDeNegocio(pedido);

    const t = await sequelize.transaction();
    try {
      await pedido.update({ status: novoStatus }, { transaction: t });
      await t.commit();

      return await this.findById(id);
    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  // ────────────────────────────────────────────────────────────────────────────
  // Alias para o controller (POST /cozinha/:id/avancar)
  // ────────────────────────────────────────────────────────────────────────────

  static async create(req) {
    const { pedidoId } = req.body;
    if (!pedidoId) throw new Error('O campo pedidoId é obrigatório.');
    return this.avancarStatus(pedidoId);
  }

  static async update(id) {
    return this.avancarStatus(id);
  }

  static async remove(_id) {
    throw new Error('A operação de remoção não é permitida no módulo de cozinha.');
  }
}

module.exports = CozinhaService;
