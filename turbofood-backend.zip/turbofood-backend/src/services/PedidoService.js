/**
 * PedidoService
 * Caso de uso: Finalizar Pedido [RF29]
 *
 * Regras de Negócio:
 *  RN01 – Endereço obrigatório: o pedido só pode ser criado se o endereço de entrega
 *          pertencer ao cliente informado (transação: cria Pedido + Itens em bloco atômico).
 *  RN02 – Estoque suficiente: nenhum produto do pedido pode ter estoque < quantidade
 *          solicitada; ao confirmar, o estoque é decrementado atomicamente.
 */

const { sequelize, Pedido, ItemPedido, Produto, EnderecoEntrega, Cliente } = require('../models');

class PedidoService {
  // ────────────────────────────────────────────────────────────────────────────
  // Helpers
  // ────────────────────────────────────────────────────────────────────────────

  static async _verificarRegrasDeNegocio(clienteId, enderecoEntregaId, itens) {
    // Validação básica de itens
    if (!itens || itens.length === 0) {
      throw new Error('O pedido deve conter pelo menos um item.');
    }

    // RN01 – Endereço pertence ao cliente
    const endereco = await EnderecoEntrega.findOne({
      where: { id: enderecoEntregaId, clienteId },
    });
    if (!endereco) {
      throw new Error(
        'Endereço de entrega não encontrado ou não pertence ao cliente informado.'
      );
    }

    // RN02 – Estoque suficiente para cada item
    for (const item of itens) {
      const produto = await Produto.findByPk(item.produtoId);
      if (!produto) {
        throw new Error(`Produto com id ${item.produtoId} não encontrado.`);
      }
      if (!produto.disponivel) {
        throw new Error(`O produto "${produto.nome}" está indisponível.`);
      }
      if (produto.estoque < item.quantidade) {
        throw new Error(
          `Estoque insuficiente para o produto "${produto.nome}". ` +
          `Disponível: ${produto.estoque}, solicitado: ${item.quantidade}.`
        );
      }
    }

    return true;
  }

  // ────────────────────────────────────────────────────────────────────────────
  // CREATE – Finalizar Pedido (transação atômica)
  // ────────────────────────────────────────────────────────────────────────────

  static async create(req) {
    const { clienteId, enderecoEntregaId, formaPagamento, itens, observacao } = req.body;

    // Verifica regras antes de abrir a transação
    await this._verificarRegrasDeNegocio(clienteId, enderecoEntregaId, itens);

    const t = await sequelize.transaction();
    try {
      // Cria o pedido principal
      const pedido = await Pedido.create(
        { clienteId, enderecoEntregaId, formaPagamento, observacao, total: 0, status: 'aguardando' },
        { transaction: t }
      );

      // Cria os itens e acumula total; decrementa estoque de cada produto
      let total = 0;
      for (const item of itens) {
        const produto = await Produto.findByPk(item.produtoId, { transaction: t });
        const subtotal = parseFloat(produto.preco) * item.quantidade;
        total += subtotal;

        await ItemPedido.create(
          {
            pedidoId: pedido.id,
            produtoId: item.produtoId,
            quantidade: item.quantidade,
            precoUnitario: produto.preco,
            subtotal,
          },
          { transaction: t }
        );

        // RN02 – Decrementa estoque atomicamente
        await produto.update(
          { estoque: produto.estoque - item.quantidade },
          { transaction: t }
        );
      }

      // Atualiza o total do pedido
      await pedido.update({ total }, { transaction: t });

      await t.commit();

      // Retorna pedido completo
      return await Pedido.findByPk(pedido.id, {
        include: [
          { association: 'cliente', attributes: { exclude: ['senha'] } },
          { association: 'enderecoEntrega' },
          {
            association: 'itens',
            include: [{ association: 'produto', include: [{ association: 'categoria' }] }],
          },
        ],
      });
    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  // ────────────────────────────────────────────────────────────────────────────
  // READ
  // ────────────────────────────────────────────────────────────────────────────

  static async findAll() {
    return Pedido.findAll({
      order: [['createdAt', 'DESC']],
      include: [
        { association: 'cliente', attributes: { exclude: ['senha'] } },
        { association: 'enderecoEntrega' },
        { association: 'itens', include: [{ association: 'produto' }] },
        { association: 'pagamentos' },
      ],
    });
  }

  static async findById(id) {
    const pedido = await Pedido.findByPk(id, {
      include: [
        { association: 'cliente', attributes: { exclude: ['senha'] } },
        { association: 'enderecoEntrega' },
        {
          association: 'itens',
          include: [{ association: 'produto', include: [{ association: 'categoria' }] }],
        },
        { association: 'pagamentos' },
        { association: 'avaliacao' },
        { association: 'entregador', attributes: { exclude: ['senha'] } },
      ],
    });
    if (!pedido) throw new Error('Pedido não encontrado.');
    return pedido;
  }

  // ────────────────────────────────────────────────────────────────────────────
  // UPDATE – Alterar dados básicos (observação, endereço) enquanto "aguardando"
  // ────────────────────────────────────────────────────────────────────────────

  static async update(id, req) {
    const pedido = await Pedido.findByPk(id);
    if (!pedido) throw new Error('Pedido não encontrado.');
    if (pedido.status !== 'aguardando') {
      throw new Error('Somente pedidos com status "aguardando" podem ser alterados.');
    }
    const { observacao, enderecoEntregaId } = req.body;
    await pedido.update({ observacao, enderecoEntregaId });
    return this.findById(id);
  }

  // ────────────────────────────────────────────────────────────────────────────
  // DELETE – Cancelar pedido (somente até "confirmado")
  // ────────────────────────────────────────────────────────────────────────────

  static async remove(id) {
    const t = await sequelize.transaction();
    try {
      const pedido = await Pedido.findByPk(id, {
        include: [{ association: 'itens' }],
        transaction: t,
      });
      if (!pedido) throw new Error('Pedido não encontrado.');

      const statusPermitidos = ['aguardando', 'confirmado'];
      if (!statusPermitidos.includes(pedido.status)) {
        throw new Error(
          `Não é possível cancelar um pedido com status "${pedido.status}". ` +
          'O cancelamento só é permitido até o status "confirmado".'
        );
      }

      // Devolve estoque dos produtos
      for (const item of pedido.itens) {
        const produto = await Produto.findByPk(item.produtoId, { transaction: t });
        await produto.update(
          { estoque: produto.estoque + item.quantidade },
          { transaction: t }
        );
      }

      await pedido.update({ status: 'cancelado' }, { transaction: t });
      await t.commit();
      return { mensagem: 'Pedido cancelado com sucesso.' };
    } catch (error) {
      await t.rollback();
      throw error;
    }
  }
}

module.exports = PedidoService;
