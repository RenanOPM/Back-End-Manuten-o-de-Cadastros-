const express = require('express');
const cors = require('cors');
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');
const { sequelize } = require('./models');

const categoriaRoutes = require('./routes/categoriaRoutes');
const produtoRoutes = require('./routes/produtoRoutes');
const clienteRoutes = require('./routes/clienteRoutes');
const entregadorRoutes = require('./routes/entregadorRoutes');
const veiculoRoutes = require('./routes/veiculoRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(express.json());

// Swagger
const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'SGPE - TurboFood API',
      version: '1.0.0',
      description:
        'Sistema de Gestão de Pedidos Exclusivos - TurboFood\nAPI RESTful para gerenciamento de categorias, produtos, clientes, entregadores e veículos.',
      contact: {
        name: 'JARR - Logistics & Innovation',
        url: 'https://github.com/ravarmes',
      },
    },
    servers: [{ url: `http://localhost:${PORT}`, description: 'Servidor de Desenvolvimento' }],
    components: {
      schemas: {
        Categoria: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            nome: { type: 'string' },
            descricao: { type: 'string' },
            icone: { type: 'string' },
            ativo: { type: 'boolean' },
            totalProdutos: { type: 'integer' },
          },
        },
        Produto: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            nome: { type: 'string' },
            descricao: { type: 'string' },
            preco: { type: 'number' },
            estoque: { type: 'integer' },
            urlImagem: { type: 'string' },
            disponivel: { type: 'boolean' },
            categoriaId: { type: 'integer' },
          },
        },
        Cliente: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            nomeCompleto: { type: 'string' },
            email: { type: 'string' },
            telefone: { type: 'string' },
            cpf: { type: 'string' },
            ativo: { type: 'boolean' },
          },
        },
        Entregador: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            nomeCompleto: { type: 'string' },
            email: { type: 'string' },
            telefone: { type: 'string' },
            cpf: { type: 'string' },
            cnh: { type: 'string' },
            tipoVeiculo: { type: 'string', enum: ['moto', 'bicicleta', 'carro'] },
            status: { type: 'string', enum: ['ativo', 'inativo', 'em_entrega'] },
          },
        },
        Veiculo: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            tipo: { type: 'string', enum: ['moto', 'bicicleta', 'carro'] },
            modelo: { type: 'string' },
            placa: { type: 'string' },
            cor: { type: 'string' },
            ano: { type: 'integer' },
            renavan: { type: 'string' },
            status: { type: 'string', enum: ['disponivel', 'em_uso', 'manutencao', 'indisponivel'] },
            entregadorId: { type: 'integer' },
          },
        },
      },
    },
  },
  apis: ['./src/routes/*.js'],
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// Rotas
app.use('/categorias', categoriaRoutes);
app.use('/produtos', produtoRoutes);
app.use('/clientes', clienteRoutes);
app.use('/entregadores', entregadorRoutes);
app.use('/veiculos', veiculoRoutes);

// Rota raiz
app.get('/', (req, res) => {
  res.json({
    sistema: 'SGPE - TurboFood',
    versao: '1.0.0',
    empresa: 'JARR - Logistics & Innovation',
    documentacao: `http://localhost:${PORT}/api-docs`,
    endpoints: {
      categorias: '/categorias',
      produtos: '/produtos',
      clientes: '/clientes',
      entregadores: '/entregadores',
      veiculos: '/veiculos',
    },
  });
});

// Inicialização
sequelize.sync({ force: false }).then(() => {
  console.log('✅ Banco de dados sincronizado (SQLite)');
  app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
    console.log(`📚 Documentação Swagger: http://localhost:${PORT}/api-docs`);
  });
}).catch((err) => {
  console.error('❌ Erro ao conectar ao banco de dados:', err);
});
