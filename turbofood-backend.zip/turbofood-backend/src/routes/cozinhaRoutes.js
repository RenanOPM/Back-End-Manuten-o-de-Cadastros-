const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/cozinhaController');

/**
 * @swagger
 * tags:
 *   name: Cozinha
 *   description: "Caso de uso: Finalizar Cozinha [RF37] — RN01: Bloqueio sem pagamento aprovado | RN02: Progressão obrigatória de status (confirmado→em_preparo→pronto)"
 */

/**
 * @swagger
 * /cozinha:
 *   get:
 *     summary: "[RF40] Lista pedidos ativos na cozinha (confirmado, em_preparo, pronto)"
 *     tags: [Cozinha]
 *     responses:
 *       200:
 *         description: Pedidos da cozinha com itens e produtos
 */
router.get('/', ctrl.listar);

/**
 * @swagger
 * /cozinha/{id}:
 *   get:
 *     summary: "[RF40] Busca pedido da cozinha pelo ID"
 *     tags: [Cozinha]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Pedido encontrado
 *       404:
 *         description: Pedido não encontrado
 */
router.get('/:id', ctrl.buscarPorId);

/**
 * @swagger
 * /cozinha/{id}/avancar:
 *   post:
 *     summary: "[RF37] Avançar status do pedido na cozinha — RN01 (pagamento aprovado) + RN02 (progressão) em transação"
 *     tags: [Cozinha]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID do pedido
 *     responses:
 *       200:
 *         description: "Status avançado: confirmado→em_preparo ou em_preparo→pronto"
 *       400:
 *         description: "RN01: Sem pagamento aprovado | RN02: Status inválido para avanço"
 *       404:
 *         description: Pedido não encontrado
 */
router.post('/:id/avancar', ctrl.avancarStatus);

/**
 * @swagger
 * /cozinha/{id}:
 *   put:
 *     summary: "[RF38] Atalho para avançar status (alias de POST /:id/avancar)"
 *     tags: [Cozinha]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Status avançado com sucesso
 *       400:
 *         description: Regra de negócio violada
 */
router.put('/:id', ctrl.avancarStatus);

module.exports = router;
