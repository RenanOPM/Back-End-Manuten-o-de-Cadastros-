const CozinhaService = require('../services/CozinhaService');

const listar = async (req, res) => {
  try {
    res.json(await CozinhaService.findAll());
  } catch (error) {
    res.status(500).json({ erro: 'Erro ao listar pedidos da cozinha', detalhe: error.message });
  }
};

const buscarPorId = async (req, res) => {
  try {
    res.json(await CozinhaService.findById(req.params.id));
  } catch (error) {
    const status = error.message.includes('não encontrado') ? 404 : 500;
    res.status(status).json({ erro: error.message });
  }
};

const avancarStatus = async (req, res) => {
  try {
    res.json(await CozinhaService.avancarStatus(req.params.id));
  } catch (error) {
    const status = error.message.includes('não encontrado') ? 404 : 400;
    res.status(status).json({ erro: error.message });
  }
};

module.exports = { listar, buscarPorId, avancarStatus };
