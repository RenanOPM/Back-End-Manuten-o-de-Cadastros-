# SGPE - TurboFood Backend

**Sistema de Gestão de Pedidos Exclusivos**  
Cliente: TurboFood | Empresa: JARR

---

## Tecnologias

- **Node.js** com **Express.js**
- **Sequelize ORM** com **SQLite** (desenvolvimento)
- **Swagger UI** para documentação da API
- **bcryptjs** para hash de senhas

---

## Instalação

```bash
npm install
```

## Execução

```bash
# Produção
npm start

# Desenvolvimento (com nodemon)
npm run dev
```

O servidor inicia em `http://localhost:3000`  
Documentação Swagger: `http://localhost:3000/api-docs`

---

## Cadastros Implementados (RF01–RF24)

### [RF01–RF04] Categorias — `/categorias`
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/categorias` | Listar todas (ordem alfabética) |
| GET | `/categorias/:id` | Buscar por ID |
| POST | `/categorias` | Criar nova categoria |
| PUT | `/categorias/:id` | Atualizar categoria |
| DELETE | `/categorias/:id` | Remover categoria |

**Regras de Negócio:**
- Nome único (unicidade garantida)
- Bloqueio de remoção se houver produtos vinculados

---

### [RF05–RF08] Produtos — `/produtos`
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/produtos` | Listar todos (filtro por `?categoriaId=`) |
| GET | `/produtos/:id` | Buscar por ID |
| POST | `/produtos` | Criar novo produto |
| PUT | `/produtos/:id` | Atualizar produto |
| DELETE | `/produtos/:id` | Remover produto |

**Regras de Negócio:**
- Categoria obrigatória
- Preço deve ser positivo (> 0)
- Controle de disponibilidade

---

### [RF09–RF12] Clientes — `/clientes`
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/clientes` | Listar todos (ordem alfabética) |
| GET | `/clientes/:id` | Buscar por ID |
| POST | `/clientes` | Cadastrar cliente |
| PUT | `/clientes/:id` | Atualizar cliente |
| DELETE | `/clientes/:id` | Remover cliente |

**Regras de Negócio:**
- Unicidade de CPF e e-mail
- Senha armazenada com hash bcrypt
- Resposta nunca inclui o campo senha

---

### [RF17–RF20] Entregadores — `/entregadores`
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/entregadores` | Listar todos (ordem alfabética) |
| GET | `/entregadores/:id` | Buscar por ID |
| POST | `/entregadores` | Cadastrar entregador |
| PUT | `/entregadores/:id` | Atualizar entregador |
| DELETE | `/entregadores/:id` | Remover entregador |

**Regras de Negócio:**
- Unicidade de CPF, CNH e e-mail
- Bloqueio de remoção se status for `em_entrega`
- Status: `ativo` | `inativo` | `em_entrega`

---

### [RF21–RF24] Veículos — `/veiculos`
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/veiculos` | Listar todos (ordem alfabética por modelo) |
| GET | `/veiculos/:id` | Buscar por ID |
| POST | `/veiculos` | Cadastrar veículo |
| PUT | `/veiculos/:id` | Atualizar veículo |
| DELETE | `/veiculos/:id` | Remover veículo |

**Regras de Negócio:**
- Unicidade de placa e RENAVAN
- Bloqueio de remoção com entregador vinculado
- Status: `disponivel` | `em_uso` | `manutencao` | `indisponivel`

---

## Requisitos Não Funcionais Atendidos

| RNF | Descrição | Status |
|-----|-----------|--------|
| RNF01 | Node.js + Express.js + Sequelize | ✅ |
| RNF02 | SQLite (dev) / PostgreSQL (prod) | ✅ |
| RNF06 | Proteção de dados (bcrypt, LGPD) | ✅ |
| RNF07 | Disponibilização web via navegador | ✅ |

---

## Estrutura do Projeto

```
turbofood-backend/
├── src/
│   ├── config/
│   │   └── database.js
│   ├── models/
│   │   ├── index.js          # Associações
│   │   ├── Categoria.js
│   │   ├── Produto.js
│   │   ├── Cliente.js
│   │   ├── Entregador.js
│   │   └── Veiculo.js
│   ├── controllers/
│   │   ├── categoriaController.js
│   │   ├── produtoController.js
│   │   ├── clienteController.js
│   │   ├── entregadorController.js
│   │   └── veiculoController.js
│   ├── routes/
│   │   ├── categoriaRoutes.js
│   │   ├── produtoRoutes.js
│   │   ├── clienteRoutes.js
│   │   ├── entregadorRoutes.js
│   │   └── veiculoRoutes.js
│   └── server.js
├── package.json
└── README.md
```
